"use client";

import { useContext, useEffect, useId } from "react";
import {
  SegtestIdContext,
  readSegtestPick,
  reportSegtestPick,
  saveSegtestPick,
} from "./segtest-picks.js";

/**
 * Numeric comparisons use a native slider with explicit bounds and a live
 * value. Arrow/Home/End keys work natively; the panel handles row-to-row Tab.
 * Values are saved with their unit, just like categorical segment labels.
 */
export function SegtestSliderRow({
  title,
  min,
  max,
  step = 1,
  unit = "",
  value,
  onChange,
}: {
  title: string;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  value: number;
  onChange: (value: number) => void;
}) {
  const id = useContext(SegtestIdContext);
  const inputId = useId();
  const format = (number: number) => `${number}${unit}`;

  useEffect(() => {
    const stored = readSegtestPick(id, title);
    const raw = stored !== null && (unit === "" || stored.endsWith(unit))
      ? (unit ? stored.slice(0, -unit.length) : stored)
      : null;
    const parsed = raw === null || raw.trim() === "" ? NaN : Number(raw);
    const restored = Number.isFinite(parsed)
      ? Number(Math.min(max, Math.max(min, min + Math.round((parsed - min) / step) * step)).toFixed(8))
      : value;
    if (restored !== value) onChange(restored);
    reportSegtestPick(id, title, format(restored));
    // Restoration happens once. Later pointer/keyboard edits are saved below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div data-segtest-row className="segtest-row">
      <div className="segtest-slider-heading">
        <label htmlFor={inputId} className="segtest-label">
          {title}
        </label>
        <output htmlFor={inputId} className="segtest-value">{format(value)}</output>
      </div>
      <input
        id={inputId}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-valuetext={format(value)}
        onChange={(event) => {
          const next = event.currentTarget.valueAsNumber;
          onChange(next);
          saveSegtestPick(id, title, format(next));
        }}
        className="segtest-slider"
      />
      <div aria-hidden="true" className="segtest-slider-bounds">
        <span>{format(min)}</span><span>{format(max)}</span>
      </div>
    </div>
  );
}
