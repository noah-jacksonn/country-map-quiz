"use client";

import { useEffect, useRef, useState, type KeyboardEvent, type PointerEvent, type RefObject } from "react";
import { MoveDiagonal2 } from "lucide-react";

// Share geometry with the panel so its handle, dot and viewport clamps agree.
export const SEGTEST_EDGE_INSET = 18;
export const SEGTEST_DOT_DIAMETER = 18;
export const SEGTEST_PANEL_GAP = 6;
const MIN_PANEL_WIDTH = 240;
const MIN_PANEL_HEIGHT = 110;

/**
 * PHONES size the panel like the iOS twin (Noah 2026-11-05), not with the
 * corner handle: a bar on the panel's edge away from the dot drags the rows
 * taller or shorter, and a test with many rows opens three rows tall instead
 * of covering the screen. The width stays fixed, because a phone panel
 * already spans the screen. "Phone" means a touch-first device (coarse
 * pointer), which also covers Chrome's device emulation.
 */
export const SEGTEST_DEFAULT_TOUCH_ROW_COUNT = 3;
/** Stored when the bar is dragged past the last row: show every row. */
export const SEGTEST_TOUCH_ROWS_GROWN_TO_FIT = -1;
/** The bar can't shrink the rows below about one row. */
const MIN_TOUCH_ROWS_HEIGHT = 56;
const COARSE_POINTER_QUERY = "(pointer: coarse)";

type Size = { width: number; height: number };
export type SegtestPanelRectangle = Size & { left: number; top: number };

/** Bare icons by request; keyboard focus remains visible without a fill. */
export const SEGTEST_FOOTER_BUTTON_CLASS = "segtest-footer-button";

/**
 * Remember freely resized geometry independently from feature-design picks.
 * An explicit position keeps the opposite corner still while resizing, rather
 * than re-anchoring to the dot each frame. The dot can still move the panel.
 */
export function useSegtestPanelSize(id: string, bounds: Size) {
  const [storedRectangle, setStoredRectangle] = useState(() => readRectangle(id));
  const latestRectangle = useRef(storedRectangle);
  const rectangle = storedRectangle ? clampPanelRectangle(storedRectangle, bounds) : null;

  const resize = (next: SegtestPanelRectangle) => {
    latestRectangle.current = clampPanelRectangle(next, bounds);
    setStoredRectangle(latestRectangle.current);
  };
  const save = () => {
    if (!latestRectangle.current) return;
    try {
      window.localStorage.setItem(`segtest.panel.rectangle.${id}`, JSON.stringify(latestRectangle.current));
    } catch {
      // The live drag still works when browser storage is unavailable.
    }
  };
  return { rectangle, resize, save };
}

/**
 * Bottom-left handle: left widens, right narrows, down makes taller.
 * Pointer capture keeps mouse, pen and touch drags alive outside the icon.
 * Arrow keys offer the same operation in 10px steps (40px with Shift).
 */
export function SegtestPanelResizeHandle({
  panelRef,
  bounds,
  onResize,
  onCommit,
}: {
  panelRef: RefObject<HTMLDivElement | null>;
  bounds: Size;
  onResize: (rectangle: SegtestPanelRectangle) => void;
  onCommit: () => void;
}) {
  const drag = useRef<{
    pointerId: number;
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
    origin: SegtestPanelRectangle;
  } | null>(null);

  const onPointerDown = (event: PointerEvent<HTMLButtonElement>) => {
    const panel = panelRef.current;
    if (!panel || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.focus();
    event.currentTarget.setPointerCapture(event.pointerId);
    const screen = panel.getBoundingClientRect();
    drag.current = {
      pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      scaleX: screen.width / panel.offsetWidth || 1,
      scaleY: screen.height / panel.offsetHeight || 1,
      origin: measurePanel(panel),
    };
  };
  const onPointerMove = (event: PointerEvent<HTMLButtonElement>) => {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    onResize(resizeFromBottomLeft(current.origin,
      (event.clientX - current.x) / current.scaleX,
      (event.clientY - current.y) / current.scaleY, bounds));
  };
  const finishDrag = (event: PointerEvent<HTMLButtonElement>) => {
    if (drag.current?.pointerId !== event.pointerId) return;
    drag.current = null;
    onCommit();
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };
  const onKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    const panel = panelRef.current;
    if (!panel || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    const step = event.shiftKey ? 40 : 10;
    const dx = event.key === "ArrowLeft" ? -step : event.key === "ArrowRight" ? step : 0;
    const dy = event.key === "ArrowUp" ? -step : event.key === "ArrowDown" ? step : 0;
    onResize(resizeFromBottomLeft(measurePanel(panel), dx, dy, bounds));
    onCommit();
  };

  return (
    <button
      type="button"
      data-segtest-panel-action
      aria-label="Resize design tester: drag or use arrow keys"
      title="Drag to resize"
      className={SEGTEST_FOOTER_BUTTON_CLASS}
      style={{ cursor: "nesw-resize", touchAction: "none", userSelect: "none" }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={finishDrag}
      onPointerCancel={finishDrag}
      onLostPointerCapture={finishDrag}
      onKeyDown={onKeyDown}
    >
      <MoveDiagonal2 className="segtest-icon" aria-hidden="true" />
    </button>
  );
}

/**
 * Whether this is a touch-first device, so the panel uses the phone sizing
 * above. Follows changes, e.g. switching device emulation on and off.
 */
export function useIsTouchLayout() {
  const [isTouchLayout, setIsTouchLayout] = useState(() => window.matchMedia(COARSE_POINTER_QUERY).matches);
  useEffect(() => {
    const query = window.matchMedia(COARSE_POINTER_QUERY);
    const update = () => setIsTouchLayout(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  return isTouchLayout;
}

/**
 * The phone rows height, remembered per panel id like the iOS twin's:
 * 0 = never dragged (opens at three rows), SEGTEST_TOUCH_ROWS_GROWN_TO_FIT
 * = dragged past the last row (every row shows), otherwise pixels.
 * `resizeRows` updates it live during a drag; `saveRows` stores it once
 * when the drag ends instead of writing on every move.
 */
export function useSegtestTouchRowsHeight(id: string) {
  const storageKey = `segtest.panel.touch-rows-height.${id}`;
  const [rowsHeight, setRowsHeight] = useState(() => readStoredNumber(storageKey) ?? 0);
  const latestRowsHeight = useRef(rowsHeight);
  const resizeRows = (next: number) => {
    latestRowsHeight.current = next;
    setRowsHeight(next);
  };
  const saveRows = () => {
    try {
      window.localStorage.setItem(storageKey, String(latestRowsHeight.current));
    } catch {
      // The live drag still works when browser storage is unavailable.
    }
  };
  return { rowsHeight, resizeRows, saveRows };
}

/**
 * The phone resize bar. It sits on the panel's edge away from the dot: the
 * top when the panel opens above the dot, the bottom when it opens below a
 * dot near the top (there you pull down to make it bigger, as on iOS).
 * Dragging away from the dot grows the rows, toward it shrinks them.
 * Dragging past the last row switches to "show every row", so the panel
 * keeps fitting if rows are added later. Pointer capture keeps the drag
 * alive when the finger leaves the bar.
 */
export function SegtestPanelGrabber({
  rowsRef,
  growsDown,
  onResize,
  onCommit,
}: {
  /** The scrolling rows viewport whose visible height the bar controls. */
  rowsRef: RefObject<HTMLDivElement | null>;
  growsDown: boolean;
  onResize: (rowsHeight: number) => void;
  onCommit: () => void;
}) {
  const drag = useRef<{
    pointerId: number;
    y: number;
    scale: number;
    /** The rows' visible height when the drag started. */
    origin: number;
    /** The height every row needs, past which the panel shows all of them. */
    fullHeight: number;
  } | null>(null);

  const onPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    const rows = rowsRef.current;
    if (!rows || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    drag.current = {
      pointerId: event.pointerId,
      y: event.clientY,
      // The panel may sit under a scaled modal: convert screen pixels back
      // to layout pixels.
      scale: rows.getBoundingClientRect().height / rows.offsetHeight || 1,
      origin: rows.clientHeight,
      fullHeight: rows.scrollHeight,
    };
  };
  const onPointerMove = (event: PointerEvent<HTMLDivElement>) => {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    const dy = (event.clientY - current.y) / current.scale;
    const proposed = Math.max(MIN_TOUCH_ROWS_HEIGHT, current.origin + (growsDown ? dy : -dy));
    onResize(proposed >= current.fullHeight ? SEGTEST_TOUCH_ROWS_GROWN_TO_FIT : Math.round(proposed));
  };
  const finishDrag = (event: PointerEvent<HTMLDivElement>) => {
    if (drag.current?.pointerId !== event.pointerId) return;
    drag.current = null;
    onCommit();
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };

  return (
    <div
      role="separator"
      aria-orientation="horizontal"
      aria-label="Drag to resize the design tester"
      className="segtest-grabber"
      data-grows-down={growsDown || undefined}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={finishDrag}
      onPointerCancel={finishDrag}
      onLostPointerCapture={finishDrag}
    >
      <span className="segtest-grabber-bar" />
    </div>
  );
}

/**
 * How tall the rows viewport must be to show exactly the first `count` rows,
 * or null when there are no more rows than that (then nothing is capped).
 * Offsets are layout pixels, and the row and the content share a scroll
 * container, so scrolling and modal scaling don't affect the result.
 */
export function measureFirstRowsHeight(content: HTMLElement, count: number): number | null {
  const rows = content.querySelectorAll<HTMLElement>("[data-segtest-row]");
  if (rows.length <= count) return null;
  const lastShownRow = rows[count - 1];
  return lastShownRow.offsetTop + lastShownRow.offsetHeight - content.offsetTop;
}

/** Keep the full panel and its draggable dot inside the viewport/modal. */
function clampPanelRectangle(rectangle: SegtestPanelRectangle, bounds: Size): SegtestPanelRectangle {
  const bottomSpace = SEGTEST_EDGE_INSET + SEGTEST_DOT_DIAMETER + SEGTEST_PANEL_GAP;
  const availableWidth = Math.max(0, bounds.width - 2 * SEGTEST_EDGE_INSET);
  const availableHeight = Math.max(0, bounds.height - SEGTEST_EDGE_INSET - bottomSpace);
  const width = clamp(rectangle.width, Math.min(MIN_PANEL_WIDTH, availableWidth), availableWidth);
  const height = clamp(rectangle.height, Math.min(MIN_PANEL_HEIGHT, availableHeight), availableHeight);
  return {
    width, height,
    left: clamp(rectangle.left, SEGTEST_EDGE_INSET, Math.max(SEGTEST_EDGE_INSET, bounds.width - SEGTEST_EDGE_INSET - width)),
    top: clamp(rectangle.top, SEGTEST_EDGE_INSET, Math.max(SEGTEST_EDGE_INSET, bounds.height - bottomSpace - height)),
  };
}

/** Clamp against the fixed upper-right corner so the handle follows the hand. */
function resizeFromBottomLeft(origin: SegtestPanelRectangle, dx: number, dy: number, bounds: Size): SegtestPanelRectangle {
  const right = origin.left + origin.width;
  const maxWidth = Math.max(0, right - SEGTEST_EDGE_INSET);
  const maxHeight = Math.max(0, bounds.height - origin.top - SEGTEST_EDGE_INSET - SEGTEST_DOT_DIAMETER - SEGTEST_PANEL_GAP);
  const width = clamp(origin.width - dx, Math.min(MIN_PANEL_WIDTH, maxWidth), maxWidth);
  const height = clamp(origin.height + dy, Math.min(MIN_PANEL_HEIGHT, maxHeight), maxHeight);
  return { left: right - width, top: origin.top, width, height };
}

/** Offset coordinates match the panel's absolute-positioning container. */
function measurePanel(panel: HTMLDivElement): SegtestPanelRectangle {
  return { left: panel.offsetLeft, top: panel.offsetTop, width: panel.offsetWidth, height: panel.offsetHeight };
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function readStoredNumber(storageKey: string): number | null {
  try {
    const stored = window.localStorage.getItem(storageKey);
    const number = stored === null ? NaN : Number(stored);
    return Number.isFinite(number) ? number : null;
  } catch {
    return null;
  }
}

function readRectangle(id: string): SegtestPanelRectangle | null {
  try {
    const stored: unknown = JSON.parse(window.localStorage.getItem(`segtest.panel.rectangle.${id}`) ?? "null");
    if (!stored || typeof stored !== "object") return null;
    const candidate = stored as SegtestPanelRectangle;
    return [candidate.left, candidate.top, candidate.width, candidate.height].every(Number.isFinite)
      && candidate.width > 0 && candidate.height > 0 ? candidate : null;
  } catch {
    return null;
  }
}
